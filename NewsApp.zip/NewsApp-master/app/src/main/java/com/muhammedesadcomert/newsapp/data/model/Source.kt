package com.muhammedesadcomert.newsapp.data.model

data class Source(
    val id: Any? = null,
    val name: String,
)
